<?php
// include database and object files
include_once '../dbconfig/database.php';
include_once '../UserFunction/user.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare user object
$user = new User($db);

$user->email = isset($_POST['email']) ? $_POST['email'] : die();
$user->password = base64_encode(isset($_POST['password']) ? $_POST['password'] : die());

$stmt = $user->login();
if($stmt->rowCount() > 0){
    
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
   
    // create array
    $user_arr=array(
        "status" => true,
        "message" => "Successfully Login!",
        "user" => 1,
    );
}
else{
    $user_arr=array(
        "status" => false,
        "message" => "Invalid Email or Password!",
        
    );
}
// make it json format
print_r(json_encode($user_arr));
?>