<?php
if(!isset($_COOKIE['LoggedIn']) && $_COOKIE['LoggedIn'] ==''){
	header ("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Saibal Creation</title>
  
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
      <link rel="stylesheet" href="./assets/css/style.css">
      <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
      <script src="./assets/js/script.js"></script>
  
</head>
<body>
	<button style="float:right;" id="logout">Logout</button>
	<br/><br/><h1 style="text-align:center;">Welcome to your Dashboard! </h1>
</body>
</html>
