   // get base url
   function baseUrl()
   {
	   return window.location.origin+'/saibaltest';
   }
   
   
   // Set Cookies for 30 minutes
   function createCookie(name, value) {
	   var date = new Date();
	   date.setTime(date.getTime()+(30* 60 * 1000));
	   var expires = "; expires="+date.toGMTString();

	   document.cookie = name+"="+value+expires+"; path=/";
	} 
	
	// Delete cookies
	function delete_cookie(name) {
	  document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
	}
	
	//Login and sinup Ajac call
	
    $(document).on('click', '.button', function() { 
    //get input field values
    var btnval          = $(this).val();
	var email_regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
   
    var flag = true;
    /********validate all our form fields***********/
    if(btnval == 'Sign In') {
		var email           = $('#email').val();
		var password         = $('#password').val();
		if (email == '' || password == '') {
			alert("Please fill all fields...!!!!!!");
			flag = false;
		} else if(!email_regex.test(email)) {
			alert("Invalid email address...!!!!!!");
			flag = false;
		}
	}
	else {
		var name         = $('#username').val();
		var email         = $('#uemail').val();
		var password         = $('#upassword').val();
		if (name == '' || email == '' || password == '') {
			alert("Please fill all fields...!!!!!!");
			flag = false;
			} else if(!email_regex.test(email)) {
			alert("Invalid email address...!!!!!!");
			flag = false;
		} else if ((password.length) < 8) {
			alert("Password should atleast 8 character in length...!!!!!!");
			flag = false;
		}
		
	}
		
    /********Validation end here ****/
    if(flag) 
    {
		if(btnval == 'Sign In') {
			var url ='./api/user/login.php';
			var data = 'email='+email+'&password='+password;
		}
		else {
			var url ='./api/user/signup.php';
			var data = 'name='+name+'&email='+email+'&password='+password;
		}
        $.ajax({
            type: 'post',
            url: url, 
            dataType: 'json',
            data: data,
            success: function(data)
            {
				if(data.status == true)
                {
                    alert(data.message);
                    var json_str = JSON.stringify(data.user);
					createCookie('LoggedIn', json_str);
                    window.location.href = baseUrl()+'/dashboard.php';
                }else{
                    alert(data.message);
                }
             }
        });
    }
});
$(document).on('click', '#logout', function() { 
	delete_cookie('LoggedIn');
	window.location.href = baseUrl()+'/index.php';
});
